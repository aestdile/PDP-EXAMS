﻿using System;
using PlansOfTravel.Models;
using PlansOfTravel.Services;

namespace PlansOfTravel
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("\n-------------------- Welcome to Travel App ---------------------");

            TravelPlanService planService = new TravelPlanService();

            while (true)
            {
                Console.WriteLine("\nSelect an option:\n");
                Console.WriteLine("*----------------------*");
                Console.WriteLine("|  1. Add Plan         |");
                Console.WriteLine("|  2. Get All Plans    |");
                Console.WriteLine("|  3. Get By Id Plan   |");
                Console.WriteLine("|  4. Update Plan      |");
                Console.WriteLine("|  5. Delete Plan      |");
                Console.WriteLine("|  6. Exit             |");
                Console.WriteLine("*----------------------*");


                Console.Write("\nChoise: ");
                string choise = Console.ReadLine();

                switch (choise)
                {
                    case "1":
                        Console.WriteLine(planService.AddPlan(new TravelPlan())); break;
                    case "2":
                        planService.GetAllPlans(); break;
                    case "3":
                        planService.GetByIdPlan(); break;
                    case "4":
                        Console.WriteLine(planService.UpdatePlan()); break;    
                    case "5": 
                        Console.WriteLine(planService.DeletePlan()); break;
                    case "6": 
                        Console.WriteLine("Programming is finished!"); return; 

                }
            }
        }
    }
}
