﻿using System;
using System.Collections.Generic;
using System.Linq;
using PlansOfTravel.Models;
using PlansOfTravel.Services.IServices;

namespace PlansOfTravel.Services
{
    public class TravelPlanService : ITravelPlanService
    {
        public string FilePath { get; set; } = "travelplans.json";
        public string AddPlan(TravelPlan travelPlan)
        {
            Console.Clear();
            Console.WriteLine("\n--------------- Add Plan -----------------\n");

            /*------------- Destination -------------*/

            Console.Write("Enter Destination: ");
            string inputDestination = Console.ReadLine();

            while (true)
            {
                if (string.IsNullOrWhiteSpace(inputDestination))
                {
                    Console.Write("Last name cannot be empty. Try again: ");
                }
                else if (inputDestination.Length < 4)
                {
                    Console.Write("Last name must be at least 3 characters long. Try again: ");
                }
                else if (inputDestination.Length > 40)
                {
                    Console.Write("Last name must be less than 40 characters long. Try again: ");
                }
                else if (!char.IsUpper(inputDestination[0]))
                {
                    Console.Write("Last name must start with an uppercase letter. Try again: ");
                }
                else
                {
                    travelPlan.Destination = inputDestination;
                    break;
                }
                inputDestination = Console.ReadLine();
            }


            /*------------ Date -------------*/

            Console.WriteLine("Date (yyyy-mm-dd): ");

            int joinYear, joinMonth, joinDay;

            Console.Write("Enter Year: ");
            string yearJoin = Console.ReadLine();

            while (true)
            {
                if (int.TryParse(yearJoin, out joinYear))
                {
                    break;
                }
                else
                {
                    Console.Write("Invalid year. Please enter a valid number: ");
                }
                yearJoin = Console.ReadLine();
            }

            Console.Write("Enter Month (1 - 12): ");
            string monthJoin = Console.ReadLine();

            while (true)
            {
                if (int.TryParse(monthJoin, out joinMonth))
                {
                    if (joinMonth >= 1 && joinMonth <= 12)
                    {
                        break;
                    }
                    else
                    {
                        Console.Write("Month must be between 1 and 12. Try again: ");
                    }
                }
                else
                {
                    Console.Write("Invalid month. Enter a valid number: ");
                }
                monthJoin = Console.ReadLine();
            }

            Console.Write("Enter Day: ");
            string dayJoin = Console.ReadLine();

            while (true)
            {
                if (int.TryParse(dayJoin, out joinDay))
                {
                    if (DateTime.TryParse($"{joinYear}-{joinMonth}-{joinDay}", out DateTime joiningDate))
                    {
                        if (joiningDate > DateTime.Now)
                        {
                            Console.Write("Plan of Date can not be in the future. Try again: ");
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        Console.Write("Invalid day for the given month/year. Try again: ");
                    }
                }
                else
                {
                    Console.Write("Invalid day. Enter a valid number: ");
                }
                dayJoin = Console.ReadLine();
            }
            travelPlan.Date = new DateTime(joinYear, joinMonth, joinDay);

            /*------------ Note ---------------*/

            Console.Write("Enter Note: ");
            string inputNote = Console.ReadLine();


            while (true)
            {
                if (string.IsNullOrWhiteSpace(inputNote))
                {
                    Console.Write("Note can not be empty. Try again: ");
                }
                else if (inputNote.Length < 3)
                {
                    Console.Write("Note must be at least 3 characters long. Try again: ");
                }
                else if (inputNote.Length > 40)
                {
                    Console.Write("Note must be less than 40 characters long. Try again: ");
                }
                else if (!char.IsUpper(inputNote[0]))
                {
                    Console.Write("Note must start with an uppercase letter. Try again: ");
                }
                else
                {
                    travelPlan.Note = inputNote;
                    break;
                }
                inputNote = Console.ReadLine();
            }

            /*-------------- Save to Data ---------------*/

            TravelPlan addTravelPlan = new TravelPlan()
            {
                Id = Guid.NewGuid(),
                Destination = travelPlan.Destination,
                Date = travelPlan.Date,
                Note = travelPlan.Note
            };  

            List<TravelPlan> travelPlans = new List<TravelPlan>();
            if (System.IO.File.Exists(FilePath))
            {
                string json = System.IO.File.ReadAllText(FilePath);
                // Teacher, u've to download 'Newtonsoft.Json' library 
                travelPlans = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TravelPlan>>(json) ?? new List<TravelPlan>();
            }

            travelPlans.Add(addTravelPlan);
            string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(travelPlans, Newtonsoft.Json.Formatting.Indented);
            System.IO.File.WriteAllText(FilePath, jsonString);


            return "\nAdd Plan is successfull!";
        }

        /*------------------Delete Plan ---------------------*/

        public string DeletePlan()
        {
            Console.Clear();
            Console.WriteLine("\n------------- Delete Plan -------------\n");

            Console.Write("Enter Guid Id: ");
            string inputId = Console.ReadLine();

            Guid id;
            while (true)
            {
                if (string.IsNullOrWhiteSpace(inputId))
                {
                    Console.Write("Id cannot be empty. Try again: ");
                }
                else if (!Guid.TryParse(inputId, out id))
                {
                    Console.Write("Id must be a valid GUID. Try again: ");
                }
                else
                {
                    break;
                }
                inputId = Console.ReadLine();
            }

            List<TravelPlan> travelPlans = new List<TravelPlan>();
            if (System.IO.File.Exists(FilePath))
            {
                string json = System.IO.File.ReadAllText(FilePath);
                travelPlans = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TravelPlan>>(json) ?? new List<TravelPlan>();
            }

            TravelPlan deletePlan = travelPlans.FirstOrDefault(e => e.Id == id);
            if (deletePlan == null)
            {
                return "Travel Plan is not found";
            }

            travelPlans.Remove(deletePlan);
            string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(travelPlans, Newtonsoft.Json.Formatting.Indented);
            System.IO.File.WriteAllText(FilePath, jsonString);


            return "\nDelete Plan is successfull!";
        }


        /*---------------- Get All Plans ---------------------*/
        public void GetAllPlans()
        {
            Console.Clear();
            Console.WriteLine("\n-------------------Get All Plans ----------------------\n");

            List<TravelPlan> travelPlans = new List<TravelPlan>();
            if (System.IO.File.Exists(FilePath))
            {
                string json = System.IO.File.ReadAllText(FilePath);
                travelPlans = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TravelPlan>>(json) ?? new List<TravelPlan>();
            }
            if (travelPlans.Count == 0)
            {
                Console.WriteLine("Travel Plans is found.");
            }
            else
            {
                foreach (var travelPlan in travelPlans)
                {
                    Console.WriteLine($"\nId: {travelPlan.Id}");
                    Console.WriteLine($"Destination: {travelPlan.Destination}");
                    Console.WriteLine($"Date: {travelPlan.Date}");
                    Console.WriteLine($"Note: {travelPlan.Note}");
                }
                Console.WriteLine();
            }
        }

        /*-------------------------- Get By Id Plan -----------------------------*/

        public void GetByIdPlan()
        {
            Console.Clear();
            Console.WriteLine("\n---------------- Get By Id -------------------\n");

            Console.Write("Enter Guid Id: ");
            string inputId = Console.ReadLine();

            Guid id;
            while (true)
            {
                if (string.IsNullOrWhiteSpace(inputId))
                {
                    Console.Write("Id cannot be empty. Try again: ");
                }
                else if (!Guid.TryParse(inputId, out id))
                {
                    Console.Write("Id must be a valid GUID. Try again: ");
                }
                else
                {
                    break;
                }
                inputId = Console.ReadLine();
            }

            List<TravelPlan> travelPlans = new List<TravelPlan>();
            if (System.IO.File.Exists(FilePath))
            {
                string json = System.IO.File.ReadAllText(FilePath);
                travelPlans = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TravelPlan>>(json) ?? new List<TravelPlan>();
            }

            TravelPlan getById = travelPlans.FirstOrDefault(e => e.Id == id);
            if (getById == null)
            {
                Console.WriteLine("Travel Plan is not found");
            }
            else
            {
                foreach (var travelPlan in travelPlans)
                {
                    Console.WriteLine($"\nId: {travelPlan.Id}");
                    Console.WriteLine($"Destination: {travelPlan.Destination}");
                    Console.WriteLine($"Date: {travelPlan.Date}");
                    Console.WriteLine($"Note: {travelPlan.Note}");
                }
            }
        }

        /*------------------------- Update -------------------------*/
        public string UpdatePlan()
        {
            Console.Clear();
            Console.WriteLine("\n--------------------- Update Travel Plan -----------------------\n");

            Console.Write("Enter Guid Id: ");
            string inputId = Console.ReadLine();

            Guid id;
            while (true)
            {
                if (string.IsNullOrWhiteSpace(inputId))
                {
                    Console.Write("Id cannot be empty. Try again: ");
                }
                else if (!Guid.TryParse(inputId, out id))
                {
                    Console.Write("Id must be a valid GUID. Try again: ");
                }
                else
                {
                    break;
                }
                inputId = Console.ReadLine();
            }

            /*------------- Destination -------------*/

            Console.Write("Enter New Destination: ");
            string inputDestination = Console.ReadLine();

            while (true)
            {
                if (string.IsNullOrWhiteSpace(inputDestination))
                {
                    Console.Write("Last name cannot be empty. Try again: ");
                }
                else if (inputDestination.Length < 4)
                {
                    Console.Write("Last name must be at least 3 characters long. Try again: ");
                }
                else if (inputDestination.Length > 40)
                {
                    Console.Write("Last name must be less than 40 characters long. Try again: ");
                }
                else if (!char.IsUpper(inputDestination[0]))
                {
                    Console.Write("Last name must start with an uppercase letter. Try again: ");
                }
                else
                {
                    break;
                }
                inputDestination = Console.ReadLine();
            }


            /*------------ Date -------------*/

            Console.WriteLine("Enter New Date (yyyy-mm-dd): ");

            int Year, Month, Day;

            Console.Write("Enter Year: ");
            string yearJoin = Console.ReadLine();

            while (true)
            {
                if (int.TryParse(yearJoin, out Year))
                {
                    break;
                }
                else
                {
                    Console.Write("Invalid year. Please enter a valid number: ");
                }
                yearJoin = Console.ReadLine();
            }

            Console.Write("Enter Month (1 - 12): ");
            string monthJoin = Console.ReadLine();

            while (true)
            {
                if (int.TryParse(monthJoin, out Month))
                {
                    if (Month >= 1 && Month <= 12)
                    {
                        break;
                    }
                    else
                    {
                        Console.Write("Month must be between 1 and 12. Try again: ");
                    }
                }
                else
                {
                    Console.Write("Invalid month. Enter a valid number: ");
                }
                monthJoin = Console.ReadLine();
            }

            Console.Write("Enter Day: ");
            string dayJoin = Console.ReadLine();

            while (true)
            {
                if (int.TryParse(dayJoin, out Day))
                {
                    if (DateTime.TryParse($"{Year}-{Month}-{Day}", out DateTime joiningDate))
                    {
                        if (joiningDate > DateTime.Now)
                        {
                            Console.Write("Plan of Date can not be in the future. Try again: ");
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        Console.Write("Invalid day for the given month/year. Try again: ");
                    }
                }
                else
                {
                    Console.Write("Invalid day. Enter a valid number: ");
                }
                dayJoin = Console.ReadLine();
            }


            /*------------ Note ---------------*/

            Console.Write("Enter New Note: ");
            string inputNote = Console.ReadLine();


            while (true)
            {
                if (string.IsNullOrWhiteSpace(inputNote))
                {
                    Console.Write("Note can not be empty. Try again: ");
                }
                else if (inputNote.Length < 3)
                {
                    Console.Write("Note must be at least 3 characters long. Try again: ");
                }
                else if (inputNote.Length > 40)
                {
                    Console.Write("Note must be less than 40 characters long. Try again: ");
                }
                else if (!char.IsUpper(inputNote[0]))
                {
                    Console.Write("Note must start with an uppercase letter. Try again: ");
                }
                else
                {
                    break;
                }
                inputNote = Console.ReadLine();
            }

            List<TravelPlan> travelPlans = new List<TravelPlan>();
            if (System.IO.File.Exists(FilePath))
            {
                string json = System.IO.File.ReadAllText(FilePath);
                travelPlans = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TravelPlan>>(json) ?? new List<TravelPlan>();
            }

            TravelPlan travelPlan = travelPlans.FirstOrDefault(e => e.Id == id);
            if (travelPlan == null)
            {
                Console.WriteLine("Travel Plan is not found");
            }

            travelPlan.Destination = inputDestination;
            travelPlan.Date = new DateTime(Year, Month, Day);
            travelPlan.Note = inputNote;
            string jsonOutput = Newtonsoft.Json.JsonConvert.SerializeObject(travelPlans, Newtonsoft.Json.Formatting.Indented);
            System.IO.File.WriteAllText(FilePath, jsonOutput);

            return "\nTravel Plan is updated successfully!";
        }
    }
}
