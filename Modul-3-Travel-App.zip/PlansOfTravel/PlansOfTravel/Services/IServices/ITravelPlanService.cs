﻿using PlansOfTravel.Models;

namespace PlansOfTravel.Services.IServices
{
    public interface ITravelPlanService
    {
        public void GetAllPlans();
        public string AddPlan(TravelPlan travelPlan);
        public string UpdatePlan();
        public string DeletePlan();
        public void GetByIdPlan();
    }
}
