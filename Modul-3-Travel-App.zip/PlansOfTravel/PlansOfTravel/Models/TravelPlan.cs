﻿using System;

namespace PlansOfTravel.Models
{
    public class TravelPlan
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Destination { get; set; }
        public DateTime Date { get; set; }
        public string Note { get; set; }
    }
}
